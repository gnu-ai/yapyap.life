// ==============================================================================
// yAp y Ap — Modèle « Session » (src/models/session.rs)
// ==============================================================================
// Une session matérialise une connexion authentifiée : le client reçoit un
// jeton secret (chaîne aléatoire) et le présente à chaque requête dans
// l'en-tête HTTP « Authorization: Bearer <jeton> ». Le serveur vérifie en
// base que le jeton existe et n'a pas expiré.
//
// Cette approche « jeton opaque + table sessions » est simple, révocable à
// tout moment (supprimer la ligne), et ne nécessite aucun état côté client
// au-delà du jeton.
// ==============================================================================

use chrono::{DateTime, Utc};
use serde::Serialize;

/// Vue interne d'une session (le jeton n'est JAMAIS renvoyé ensuite).
#[derive(Debug, Serialize)]
pub struct Session {
    pub jeton: String,
    pub utilisateur: i64,
    pub expire_le: DateTime<Utc>,
}

/// Réponse renvoyée au client à la connexion : le jeton à conserver.
#[derive(Debug, Serialize)]
pub struct TokenResponse {
    pub jeton: String,
    pub expire_le: DateTime<Utc>,
}
