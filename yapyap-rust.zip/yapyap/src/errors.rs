// ==============================================================================
// yAp yAp — Types d'erreurs applicatifs (errors.rs)
// ==============================================================================
// Philosophie Rust : les erreurs ne sont pas des « exceptions » interceptées
// n'importe où, mais des VALEURS de type explicite, propagées par `?` et
// `Result<T, E>`. Ce fichier définit LE type d'erreur unique de
// l'application, capable de représenter aussi bien :
//   - une erreur PostgreSQL (pilote tokio-postgres) ;
//   - une erreur d'authentification métier ;
//   - une requête cliente malformée.
//
// Chaque variante est associée à un code de statut HTTP et un message
// public : jamais de fuite de détails internes vers le client.
// ==============================================================================

use axum::http::StatusCode;
use axum::response::{IntoResponse, Response};
use axum::Json;

/// Erreur applicative unifiée. `#[from]` permet la conversion automatique
/// depuis les types des bibliothèques : `?` fonctionne alors sans collage
/// de code de conversion.
#[derive(Debug, thiserror::Error)]
pub enum AppError {
    /// Erreur émise par le pilote PostgreSQL.
    #[error("erreur base de données : {0}")]
    Db(#[from] tokio_postgres::Error),

    /// Ressource introuvable (profil, sortie...).
    #[error("ressource introuvable : {0}")]
    NotFound(String),

    /// Authentification invalide ou absente (jeton de session expiré...).
    #[error("authentification requise")]
    Unauthorized,

    /// Données envoyées par le client invalides (créneaux impossibles...).
    #[error("requête invalide : {0}")]
    BadRequest(String),

    /// Conflit d'unicité (pseudonyme déjà pris, e-mail existant...).
    #[error("conflit : {0}")]
    Conflict(String),
}

// ------------------------------------------------------------------------------
// Conversion de l'erreur applicative en réponse HTTP.
// `IntoResponse` est le « pont » entre notre type et axum : le framework
// sait ainsi transformer un `Result<_, AppError>` renvoyé par un handler
// en réponse exploitable par le client.
// ------------------------------------------------------------------------------
impl IntoResponse for AppError {
    fn into_response(self) -> Response {
        // Le couple (statut, message public) dépend de la variante : c'est
        // ici et ici seulement que la politique HTTP est décidée.
        let (status, message) = match &self {
            AppError::Db(e) => {
                // Une erreur SGBD est UN PROBLÈME INTERNE : on la journalise
                // intégraement côté serveur, mais le client ne voit qu'un
                // « 500 » générique (pas de fuite d'informations).
                tracing::error!("erreur base de données : {e}");
                (StatusCode::INTERNAL_SERVER_ERROR, "erreur interne".to_string())
            }
            AppError::NotFound(what) => (StatusCode::NOT_FOUND, what.clone()),
            AppError::Unauthorized => (StatusCode::UNAUTHORIZED, "authentification requise".to_string()),
            AppError::BadRequest(why) => (StatusCode::BAD_REQUEST, why.clone()),
            AppError::Conflict(why) => (StatusCode::CONFLICT, why.clone()),
        };

        // Corps de réponse JSON uniforme : { "erreur": "..." }.
        let body = Json(serde_json::json!({ "erreur": message }));
        (status, body).into_response()
    }
}
